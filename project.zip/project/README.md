## Input dense are in COO format as below

COO format:

       row_index col_index value
          1         1         1
          1         2        -1
          1         3        -3   
          2         1        -2
          2         2         5
          3         3         4
          3         4         6
          3         5         4
          4         1        -4
          4         3         2
          4         4         7     
          5         2         8
          5         5        -5